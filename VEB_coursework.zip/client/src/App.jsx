import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import {AboutUs, Login, Registration, Support, Collaboration, First, Quiz } from './pages'
import Theory from './pages/Theory';
import Provisions from './pages/Provisions';
import Header from './components/Header';
import { baseLinks } from './common/headerSettings';
import Profile from './pages/Profile';

function App() {
  return (
    <Router>
      
      <Routes>
        <Route path="/" element={<First />} />
        <Route path="/about-us" element={<AboutUs />} />
        <Route path="/support" element={<Support />} />
        <Route path="/collaboration" element={<Collaboration />} />
        <Route path="/register" element={<Registration />} />
        <Route path="/login" element={<Login />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/theory" element={<Theory />} />
        <Route path="/provisions" element={<Provisions />} />
        <Route path="/quiz" element={<Quiz />} />
      </Routes>
    </Router>
  );
}

export default App;
