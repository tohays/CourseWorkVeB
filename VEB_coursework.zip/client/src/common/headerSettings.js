export const baseLinks = [
    { text: 'Головна', to: '/' },
    { text: 'Наші переваги', to: '/about-us' },
    { text: 'Служба підтримки', to: '/support' },
    { text: 'Співпраця', to: '/collaboration' },
    { text: 'Увійти/Реєстрація', to: '/login' },
];

export const authorizedLinks = [
    { text: 'Мій профіль', to: '/profile' },
    { text: 'Теорія', to: '/provisions' },
    { text: 'Практика', to: '/provisions' },
    { text: 'Служба підтримки', to: '/support' },
    { text: 'Вийти з профілю', to: '/' },
]