import React from 'react';
import { Link } from 'react-router-dom';
import '../styles/header.css';

const Header = ({ links }) => {
  return (
    <header className="header">
      <nav className="nav-bar">
        {links.map((link, index) => (
          <Link key={index} to={link.to} className="nav-item">
            {link.text}
          </Link>
        ))}
      </nav>
    </header>
  );
};

export default Header;