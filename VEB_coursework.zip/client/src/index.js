import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App'; // Головний компонент додатка
import './styles/first.css'; // Глобальні стилі для головної сторінки

// Ініціалізація кореневого елемента
const root = ReactDOM.createRoot(document.getElementById('root'));

// Рендеринг додатка
root.render(
  <React.StrictMode>    
    <App />
  </React.StrictMode>
);
