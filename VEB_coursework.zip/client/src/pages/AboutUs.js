import React from 'react';
import '../styles/aboutUs.css';
import laptop from '../assets/laptop.png'
import businessPlan from '../assets/businessPlan.png'
import note from '../assets/note.png'
import teamSupport from '../assets/teamSupport.png'
import thumbUp from '../assets/thumbUp.png'
import speedometer from '../assets/speedometer.png'
import { baseLinks } from '../common/headerSettings';
import Header from '../components/Header';

function AboutUs() {
  return (
    <>
      <Header links={baseLinks} />
      <div className="about-us">
        <h1 className="advantages-title">Наші переваги</h1>
        <div className="rectangle-1">
          <img src={thumbUp} alt="Офіційна база запитань" className="thumb-up-image" />
          <h2 className="title1">Офіційна база запитань</h2>
          <p className="content1">Ти вирішуєш саме ті питання, які будуть на іспиті в сервісному центрі МВС.</p>
        </div>
        <div className="rectangle-2">
          <img src={laptop} alt="Єдиний доступ" className="laptop-image" />
          <h2 className="title2">Єдиний доступ</h2>
          <p className="content2">Створивши один акаунт, ти зможеш користуватися безкоштовно як вебверсією, так і додатком.</p>
        </div>
        <div className="rectangle-3">
          <img src={businessPlan} alt="Простий інтерактивний інтерфейс" className="plan-image" />
          <h2 className="title3">Простий інтерактивний інтерфейс</h2>
          <p className="content3">Практичні завдання, мініігри з друзями, симуляції, заучування за флешкартками для ефективного навчання.</p>
        </div>
        <div className="rectangle-4">
          <img src={note} alt="Вся необхідна теорія" className="note-image" />
          <h2 className="title4">Вся необхідна теорія</h2>
          <p className="content4">Конспекти, уроки та відео по темах.</p>
        </div>
        <div className="rectangle-5">
          <img src={speedometer} alt="Тематичні тести" className="speed-image" />
          <h2 className="title5">Тематичні тести</h2>
          <p className="content5">Проходження тестів, як і по всіх правилах ПДР, так і темах.</p>
        </div>
        <div className="rectangle-6">
          <img src={teamSupport} alt="Мотиваційна система" className="team-image" />
          <h2 className="title6">Мотиваційна система</h2>
          <p className="content6">Зарахування вогників за щоденне користування платформою.</p>
        </div>
        <div className="rectangle-7"></div>
      </div>
    </>
  );
}

export default AboutUs;
