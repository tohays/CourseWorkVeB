import React, { useState } from 'react';
import '../styles/support.css'; // Підключення CSS
import { baseLinks } from '../common/headerSettings';
import Header from '../components/Header';

function Collaboration() {
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [statusMessage, setStatusMessage] = useState('');

  // Оновлення даних форми
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  // Обробка форми
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      console.log(formData);
      const response = await fetch('http://localhost:3001/submit-collaboration', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        setStatusMessage('Ваш запит на співпрацю успішно надіслано!');
        setFormData({ name: '', email: '', message: '' });
      } else {
        setStatusMessage('Сталася помилка. Спробуйте ще раз.');
      }
    } catch (error) {
      setStatusMessage('Помилка сервера. Спробуйте пізніше.');
    }
  };

  return (
    <>
    <Header links={baseLinks} />
    <div className="support-container">
      <header className="support-header">
        Бажаєте співпрацювати?
      </header>
      <main className="support-main">
        <div className="form-with-road">
          <form className="support-form" onSubmit={handleSubmit}>
            <input
              className="input-name"
              type="text"
              name="name"
              placeholder="Введіть своє ім'я"
              value={formData.name}
              onChange={handleChange}
              required
            />
            <input
              className="input-email"
              type="email"
              name="email"
              placeholder="Введіть свою електронну скриньку"
              value={formData.email}
              onChange={handleChange}
              required
            />
            <textarea
              className="area"
              name="message"
              placeholder="Коротко опишіть пропозицію співпраці"
              rows="6"
              value={formData.message}
              onChange={handleChange}
              required
            ></textarea>
            <button className="button" type="submit">Відправити</button>
            {statusMessage && <p className="status-message">{statusMessage}</p>}
          </form>
        </div>
      </main>
    </div>
    </>
  );
}

export default Collaboration;
