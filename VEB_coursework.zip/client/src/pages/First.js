import React from 'react';
import '../styles/first.css';
import RoadImage from '../assets/road.png';
import FacebookImage from '../assets/facebookLogo.png';
import InstagramImage from '../assets/instagramLogo.png';
import TikTokImage from '../assets/logoTiktok.png';
import TelegramImage from '../assets/telegramLogo.png';
import { baseLinks } from '../common/headerSettings';
import Header from '../components/Header';

function First() {
    return ( 
    <>
      <Header links={baseLinks}/>
      <div className="main-container">
        <img src={RoadImage} style={{position: 'absolute', left: 0, zIndex: -1, top: '20px'}}/>
        <div className="main-content">
          <h1 className="title">DriftDrive</h1>
          <p className="subtitle">Вивчати правила — легко, цікаво, безпечно!</p>
          <p className="description">
            Сучасна платформа для вивчення правил дорожнього руху для дітей та
            дорослих. Інтерактивні уроки, тестування, симуляції та мотиваційна
            система роблять навчання цікавим і ефективним, допомагаючи школярам
            засвоїти знання та підготуватися до безпечної поведінки на дорозі.
          </p>
          <p className="cta">Розпочни навчання прямо зараз!</p>
        </div>

        <div className="social-media">
          <a href="https://instagram.com" target="_blank" rel="noopener noreferrer">
            <img src={InstagramImage} alt="Instagram" className="social-icon" />
          </a>
          <a href="https://telegram.org" target="_blank" rel="noopener noreferrer">
            <img src={TelegramImage} alt="Telegram" className="social-icon" />
          </a>
          <a href="https://facebook.com" target="_blank" rel="noopener noreferrer">
            <img src={FacebookImage} alt="Facebook" className="social-icon" />
          </a>
          <a href="https://tiktok.com" target="_blank" rel="noopener noreferrer">
            <img src={TikTokImage} alt="TikTok" className="social-icon" />
          </a>
        </div>
      </div>
    </>
)}

export default First;