import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom'; // Для внутрішніх посилань
import '../styles/login.css'; // Підключення CSS
import { baseLinks } from '../common/headerSettings';
import Header from '../components/Header';

function Login() {
  const [formData, setFormData] = useState({ email: '', password: '' });
  const navigation = useNavigate();

  // Функція для оновлення стану
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  // Обробка форми входу
  const handleSubmit = async (e) => {
    e.preventDefault();
    // Відправка запиту на сервер
    const response = await fetch('http://localhost:3001/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData)
    });

    const result = await response.json();
    if (response.ok) {
      alert(`Ласкаво просимо, ${result.username}!`);
      navigation('/profile');
    } else {
      alert('Невірний логін або пароль.');
    }
  };

  return (
    <>
      <Header links={baseLinks} />
      <div className="container">
        <div className="right-pane">
          <div className="frame57">
            <div className="frame55">
              <h1 className="welcome-text">Вітаємо у DriftDrive!</h1>
            </div>
            <div className="frame79">
              <p className="description-text">Введіть дані для входу в акаунт.</p>
            </div>
            <form className="frame56" onSubmit={handleSubmit}>
              <div className="input-group">
                <input
                  type="email"
                  name="email"
                  placeholder="Введіть Ваш email"
                  className="input-field"
                  value={formData.email}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="input-group">
                <input
                  type="password"
                  name="password"
                  placeholder="Введіть пароль"
                  className="input-field"
                  value={formData.password}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="frame40">
                <button className="login-button" type="submit">Увійти</button>
              </div>
            </form>
            <div className="frame78">
              <p className="account-text">Ще немає акаунту?</p>
              <Link to="/register" className="register-link">Зареєструйтесь!</Link>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Login;
