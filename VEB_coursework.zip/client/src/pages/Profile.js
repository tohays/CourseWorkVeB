import React from 'react';
import '../styles/profile.css';
import Header from '../components/Header';
import { authorizedLinks } from '../common/headerSettings';
import PracticeImage from '../assets/practice.png';
import TheoryImage from '../assets/theory.png';
import { Link } from 'react-router-dom';

const sections = [
  {
    title: 'Мій прогрес',
    content: (
      <>
        <p>Ваш прогрес</p>
        <div className="progress-icons">
          <span role="img" aria-label="fire">🔥</span>
          <span role="img" aria-label="fire">🔥</span>
          <span role="img" aria-label="fire">🔥</span>
          <span role="img" aria-label="fire">🔥</span>
          <span role="img" aria-label="fire">🔥</span>
          <span role="img" aria-label="fire">🔥</span>
          <span role="img" aria-label="drop">💧</span>
        </div>
        <p className="weekdays">Пн Вт Ср Чт Пт Сб Нд</p>
        <button className="action-button" style={{marginTop: '35px'}}>Подивитись</button>
      </>
    ),
  },
  {
    title: 'Теорія',
    image: TheoryImage,
    description: 'Правила дорожнього руху',
    buttonText: 'Перейти до вивчення',
  },
  {
    title: 'Практика',
    image: PracticeImage,
    description: 'Тести по темах та всьому курсу ПДР',
    buttonText: 'Гайда закріпити знання!',
  },
];

export default function Profile () {
  return (
    <>
    <Header links={authorizedLinks} />
    <div className="page-container" style={{marginTop: '125px'}}>
      {sections.map((section, index) => (
        <div key={index} className="card">
          <h2 className="card-title">{section.title}</h2>
          {section.image && (
            <img src={section.image} alt={section.title} className="card-image" />
          )}
          {section.content || (
            <>
              <p className="card-description">{section.description}</p>
              <Link to={'/provisions'} style={{marginTop: '15px'}}>
                <button className="action-button">{section.buttonText}</button>
              </Link>
            </>
          )}
        </div>
      ))}
    </div>
    </>
  );
};
