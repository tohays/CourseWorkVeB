// Import React and CSS
import React from 'react';
import '../styles/provisions.css';
import CarImage from '../assets/yellow-car.png';
import Header from '../components/Header';
import { authorizedLinks } from '../common/headerSettings';
import { Link } from 'react-router-dom';

// Configuration for rows
const rowsConfig = [
  { id: 1, text: 'Загальні положення', percentage: 100 },
  { id: 2, text: 'Обов’язки і права водіїв', percentage: 0 },
  { id: 3, text: 'Обов’язки і права пішоходів', percentage: 0 },
  { id: 4, text: 'Вимоги до велосипедистів', percentage: 0 },
  { id: 5, text: 'Попереджувальні знаки', percentage: 0 },
  { id: 6, text: 'Основи безпечного водіння', percentage: 0 },
  { id: 7, text: 'Надання першої медичної допомоги', percentage: 0 },
  { id: 8, text: 'Обов’язки і права водіїв', percentage: 0 },
  { id: 9, text: 'Обов’язки і права водіїв', percentage: 0 },
  { id: 10, text: 'Обов’язки і права водіїв', percentage: 0 },
];

// Main Component
export default function Provisions () {
  return (
    <>
    <Header links={authorizedLinks} />
    <div className="page-container">
      <div className="rows-container">
        {rowsConfig.map((row) => (
          <div className="row" key={row.id}>
            <div className="row-left">
              <span className="row-id">{row.id.toString().padStart(2, '0')}</span>
              {
                row.text === 'Загальні положення' ? 
                    <Link to={'/theory'} style={{ textDecoration: 'none', color: 'black' }}>{row.text}</Link> : 
                    <span className='row-text'>{row.text}</span>
              }
            </div>
            <div className="row-right">
              <div className="progress-bar">
                <div
                  className="progress-bar-fill"
                  style={{ width: `${row.percentage}%` }}
                ></div>
              </div>
              <span className="percentage">{row.percentage}%</span>
            </div>
          </div>
        ))}
      </div>
      <div className="image-container">
        <img src={CarImage} alt="Car" className="car-image" width={300}/>
      </div>
    </div>
    </>
  );
};
