import React, { useState } from 'react';
import Header from '../components/Header';
import { authorizedLinks } from '../common/headerSettings';
import { quizConfig } from '../common/quizConfig';
import '../styles/quiz.css';

const resultMessages = {
    0: 'Тобі ще вчитись і вчитись!',
    2: 'Спробуй ще раз!',
    5: 'Ти молодець!',
    10: 'Ти все відповів правильно! Супер!'
  };

function Quiz () {
  const [userAnswers, setUserAnswers] = useState({});
  const [result, setResult] = useState({});
  const [score, setScore] = useState(null);
  const [message, setMessage] = useState('');

  const handleChange = (questionId, answerIndex) => {
    setUserAnswers((prev) => ({ ...prev, [questionId]: answerIndex }));
  };

  const handleSubmit = () => {
    const newResult = {};
    let correctCount = 0;
    quizConfig.forEach((q) => {
      if (userAnswers[q.id] === q.correct) {
        newResult[q.id] = 'correct';
        correctCount++;
      } else {
        newResult[q.id] = 'incorrect';
      }
    });
    alert(`${correctCount}/${quizConfig.length} ${resultMessages[correctCount] || 'Маємо що маємо'}`);
    setResult(newResult);
    setScore(`${correctCount}/${quizConfig.length}`);
    setMessage(resultMessages[correctCount] || 'Маємо що маємо');
  };

  return (
    <>
    <Header links={authorizedLinks}/>
    <div className='container'>
      <h1>Опитування</h1>
      {quizConfig.map((q) => (
        <div
          key={q.id}
          style={{
            border: result[q.id] === 'correct' ? '2px solid green' : result[q.id] === 'incorrect' ? '2px solid red' : '2px solid gray',
            marginBottom: '20px',
            padding: '10px',
            borderRadius: '30px',
            width: '800px'
          }}
        >
          <p>{q.question}</p>
          {q.options.map((option, index) => (
            <label key={index} style={{ display: 'block', margin: '5px 0' }}>
              <input
                type="radio"
                name={`question-${q.id}`}
                value={index}
                onChange={() => handleChange(q.id, index)}
              />
              {option}
            </label>
          ))}
        </div>
      ))}
      <div>
        <button 
          className='check-button'
          onClick={handleSubmit}
        >
          Перевірити відповіді
        </button>
      </div>
    </div>
    </>
  );
}

export default Quiz;