import React, { useState } from 'react';
import { Link } from 'react-router-dom'; // Для внутрішньої навігації
import '../styles/registration.css'; // Підключення CSS
import { baseLinks } from '../common/headerSettings';
import Header from '../components/Header';

function Registration() {
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    confirmPassword: '',
  });

  const [statusMessage, setStatusMessage] = useState('');

  // Оновлення даних форми
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  // Обробка форми
  const handleSubmit = async (e) => {
    e.preventDefault();

    // Перевірка, чи збігаються паролі
    if (formData.password !== formData.confirmPassword) {
      setStatusMessage('Паролі не збігаються!');
      return;
    }

    try {
      const response = await fetch('http://localhost:3001/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: formData.username,
          email: formData.email,
          password: formData.password,
        }),
      });

      if (response.ok) {
        setStatusMessage('Реєстрація успішна! Ви можете увійти.');
        setFormData({ username: '', email: '', password: '', confirmPassword: '' });
      } else {
        setStatusMessage('Сталася помилка під час реєстрації.');
      }
    } catch (error) {
      setStatusMessage('Помилка сервера. Спробуйте пізніше.');
    }
  };

  return (
    <>
      <Header links={baseLinks} />
      <div className="container">
        <div className="right-pane">
          <div className="frame57">
            <div className="frame55">
              <h1 className="welcome-text">Вітаємо у DriftDrive!</h1>
            </div>
            <div className="frame79">
              <p className="description-text">Заповніть форму для створення акаунту.</p>
            </div>
            <form className="frame56" onSubmit={handleSubmit}>
              <div className="input-group">
                <input
                  type="text"
                  name="username"
                  placeholder="Введіть Ваше ім'я"
                  className="input-field"
                  value={formData.username}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="input-group">
                <input
                  type="email"
                  name="email"
                  placeholder="Введіть Ваш email"
                  className="input-field"
                  value={formData.email}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="input-group">
                <input
                  type="password"
                  name="password"
                  placeholder="Введіть пароль"
                  className="input-field"
                  value={formData.password}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="input-group">
                <input
                  type="password"
                  name="confirmPassword"
                  placeholder="Підтвердіть пароль"
                  className="input-field"
                  value={formData.confirmPassword}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="frame40">
                <button className="login-button" type="submit">Зареєструватися</button>
              </div>
            </form>
            {statusMessage && <p className="status-message">{statusMessage}</p>}
            <div className="frame78">
              <p className="account-text">Вже маєте акаунт?</p>
              <Link to="/login" className="register-link">Увійдіть!</Link>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Registration;
