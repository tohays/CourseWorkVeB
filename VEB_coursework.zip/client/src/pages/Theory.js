import { Link } from "react-router-dom";
import { authorizedLinks } from "../common/headerSettings";
import { theoryConfig } from "../common/theoryConfig";
import Header from "../components/Header";
import '../styles/theory.css';

export default function Theory() {
    return <>
        <Header links={authorizedLinks}/>
        <div className="container">
            {theoryConfig.map(t => (
                <div className="theory-item">
                    {t.text}
                </div>
            ))}
        </div>
        <div style={{display: 'flex', justifyContent: 'center'}}>
            <Link to='/quiz' className="action-button">Пройти тест</Link>
        </div>
    </>;
}