export {default as AboutUs} from './AboutUs';
export {default as Collaboration} from './Collaboration';
export {default as Login} from './Login';
export {default as Registration} from './Registration';
export {default as Support} from './Support';
export {default as First} from './First';
export {default as Quiz} from './Quiz';