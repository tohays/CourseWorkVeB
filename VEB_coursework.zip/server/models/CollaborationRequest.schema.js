const { mongoose } = require("mongoose");

const collaborationRequestSchema = new mongoose.Schema({
    name: { type: String, required: true, unique: true },
    email: { type: String, required: true, unique: true },
    message: { type: String, required: true }
});

const CollaborationRequest = mongoose.model('CollaborationRequest', collaborationRequestSchema);

module.exports = {
    CollaborationRequest,
}