const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const bcrypt = require('bcrypt');
const session = require('express-session');
const mongoose = require('mongoose');

const { User } = require('./models/User.schema');
const { SupportRequest } = require('./models/SupportRequest.schema');
const { CollaborationRequest } = require('./models/CollaborationRequest.schema');

require('dotenv').config();

const app = express();

app.use(session({
    secret: process.env.SESSION_SECRET,
    resave: false,
    saveUninitialized: false
}));

app.use(cors());
app.use(bodyParser.json());

// Реєстрація користувача
app.post('/register', async (req, res) => {
    const { username, email, password } = req.body;
    if (!username || !email || !password) {
      return res.status(400).json({ message: 'Username, password and email are required' });
    }
  
    try {
      const hashedPassword = await bcrypt.hash(password, 10);
      const newUser = new User({ username, email, password: hashedPassword });
      await newUser.save();
      res.status(201).json({ message: 'User registered successfully' });
    } catch (err) {
      console.error(err);
      res.status(500).json({ message: 'Error registering user' });
    }
  });

// Вхід користувача
app.post('/login', async (req, res) => {
  const { email, password } = req.body;
  
  if (!email || !password) {
    return res.status(400).json({ message: 'Email and password are required' });
  }

  try {
    const user = await User.findOne({ email });
    if (!user) {
        return res.status(400).json({ message: 'Invalid username or password' });
    }

    // Порівнюємо хеші паролів
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
        return res.status(400).json({ message: 'Invalid username or password' });
    }

    if (res.session) {
      res.session.user = { id: user._id, username: user.username, email: user.email};
    }
    res.status(200).json(user);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Error logging in' });
  }
});

app.post('/logout', (req, res) => {
    if (req.session.user) {
      req.session.destroy(err => {
        if (err) {
          console.error(err);
          return res.status(500).json({ message: 'Error logging out' });
        }
        res.clearCookie('connect.sid'); // Чистимо сесію
        res.status(200).json({ message: 'Logout successful' });
      });
    } else {
      res.status(400).json({ message: 'No user logged in' });
    }
  });

// Обробка форми підтримки
app.post('/submit-support', async (req, res) => {
    const { name, email, message } = req.body;
    if (!name || !email || !message) {
      return res.status(400).json({ message: 'Name, email, and message are required' });
    }
  
    try {
      const supportRequest = new SupportRequest({ name, email, message });
      await supportRequest.save();
      res.status(200).json({ message: 'Support request submitted successfully' });
    } catch (err) {
      console.error(err);
      res.status(500).json({ message: 'Error submitting support request' });
    }
  });
  

// Обробка форми співпраці
app.post('/submit-collaboration', async (req, res) => {
    const { name, email, message } = req.body;
    console.log(name, email, message)
    if (!name || !email || !message) {
      return res.status(400).json({ message: 'Name, email, and message are required' });
    }
  
    try {
      const collaborationRequest = new CollaborationRequest({ name, email, message });
      await collaborationRequest.save();
      res.status(200).json({ message: 'Collaboration request submitted successfully' });
    } catch (err) {
      console.error(err);
      res.status(500).json({ message: 'Error submitting collaboration request' });
    }
});

app.listen(3001, () => {
  console.log('Сервер працює на порту 3001');
});

mongoose.connect(process.env.MONGO_CONNECTION)
    .then(() => console.log('Connected to MongoDB'))
    .catch(() => console.log('Error happened whiel connecting to MongoDB'));
